import os
import random
from flask import Flask, render_template, request, jsonify

app = Flask(__name__, template_folder="templates", static_folder="statics")




@app.route('/')
def home():
    return render_template("index.html")
@app.route('/levels')
def levels():
    return render_template("levels.html")

@app.route("/game")
def game():
    category = request.args.get("category")
    level = request.args.get("level")
    return render_template("game.html", category=category, level=level)

    if not words:  # If no words are loaded, return an error page
        return "Error: No words available for this category and level.", 500

    chosen_word, word_hint = random.choice(words)  # Pick a random word
    return render_template('game.html', category=category, level=level, word=chosen_word, hint=word_hint)
@app.route("/get_word")
def get_word():
    return render_template("game.html")
@app.route("/game1")
def game1():
    return render_template("game1.html")
@app.route("/game1.2")
def game1_2():
    return render_template("game1.2.html")
@app.route("/game1.3")
def game1_3():
    return render_template("game1.3.html")
@app.route("/game2")
def game2():
    return render_template("game2.html")
@app.route("/game2.2")
def game2_2():
    return render_template("game2.2.html")
@app.route("/game2.3")
def game2_3():
    return render_template("game2.3.html")
@app.route("/game3")
def game3():
    return render_template("game3.html")
@app.route("/game3.2")
def game3_2():
    return render_template("game3.2.html")
@app.route("/game3.3")
def game3_3():
    return render_template("game3.3.html")
@app.route("/game4")
def game4():
    return render_template("game4.html")
@app.route("/game4.2")
def game4_2():
    return render_template("game4.2.html")
@app.route("/game4.3")
def game4_3():
    return render_template("game4.3.html")

@app.route('/game-over')
def game_over():
    return render_template("game-over.html")
@app.route('/game-over1')
def game_over1():
    return render_template("game-over1.html")
@app.route('/game-over2')
def game_over2():
    return render_template("game-over2.html")
@app.route('/game-over3')
def game_over3():
    return render_template("game-over3.html")
@app.route('/game-over4')
def game_over4():
    return render_template("game-over4.html")
@app.route('/game-over5')
def game_over5():
    return render_template("game-over5.html")
@app.route('/game-over6')
def game_over6():
    return render_template("game-over6.html")
@app.route('/game-over7')
def game_over7():
    return render_template("game-over7.html")
@app.route('/game-over8')
def game_over8():
    return render_template("game-over8.html")
@app.route('/game-over9')
def game_over9():
    return render_template("game-over9.html")
@app.route('/game-over10')
def game_over10():
    return render_template("game-over10.html")
@app.route('/game-over11')
def game_over11():
    return render_template("game-over11.html")
@app.route('/game-over12')
def game_over12():
    return render_template("game-over12.html")



if __name__ == "__main__":
    app.run(debug=True)
