// words.js - Contains categorized words and questions

const wordsData = [
             { "word": "television", question: "Which electronic device is used to watch shows and movies?" },
  { "word": "microscope", question: "Which scientific instrument is used to see small objects?" },
  { "word": "thermometer", question: "Which device is used to measure temperature?" },
  { "word": "refrigerator", question: "Which appliance is used to keep food cool?" },
  { "word": "sewingmachine", question: "Which device is used to stitch fabric together?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
                 setTimeout(() => {
window.location.href = "/game-over9";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   