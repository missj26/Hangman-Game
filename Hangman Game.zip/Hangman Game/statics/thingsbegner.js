// words.js - Contains categorized words and questions

const wordsData = [
            { "word": "pen", question: "Which item is used to write on paper?" },
  { "word": "phone", question: "Which device allows you to make calls and send messages?" },
  { "word": "book", question: "Which object is made of pages and tells a story?" },
  { "word": "ball", question: "Which round object is used in many sports?" },
  { "word": "clock", question: "Which item tells you the time?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over7";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   