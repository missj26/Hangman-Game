document.addEventListener("DOMContentLoaded", () => {
    const musicBtn = document.getElementById("music-btn");
    const music = document.getElementById("background-music");
    const settingsBtn = document.getElementById("settings-btn");
    const settingsModal = document.getElementById("settings-modal");
    const closeSettings = document.getElementById("close-settings");
    const themeToggle = document.getElementById("theme-toggle");
    const themeLabel = document.getElementById("theme-label");
    const body = document.body;

    // Music Button Toggle
    musicBtn.addEventListener("click", () => {
        if (music.paused) {
            music.play();
            musicBtn.textContent = "Music: ON";
        } else {
            music.pause();
            musicBtn.textContent = "Music: OFF";
        }
    });

    // Open Settings Modal
    settingsBtn.addEventListener("click", () => {
        settingsModal.style.display = "block";
    });

    // Close Settings Modal
    closeSettings.addEventListener("click", () => {
        settingsModal.style.display = "none";
    });

    // Theme Toggle (Dark Mode / Light Mode)
    themeToggle.addEventListener("change", () => {
        if (themeToggle.checked) {
            body.classList.add("light-mode");
            themeLabel.textContent = "Light Mode";
        } else {
            body.classList.remove("light-mode");
            themeLabel.textContent = "Dark Mode";
        }
    });
});
document.addEventListener("DOMContentLoaded", function () {
    // Load theme preference
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        document.getElementById("dark-mode-toggle").checked = true;
    }

    // Load music preference
    const music = document.getElementById("bg-music");
    if (localStorage.getItem("music") === "on") {
        music.play();
        document.getElementById("music-btn").textContent = "Music: ON";
    }

    // Dark mode toggle
    document.getElementById("dark-mode-toggle").addEventListener("change", function () {
        if (this.checked) {
            document.body.classList.add("dark-mode");
            localStorage.setItem("darkMode", "enabled");
        } else {
            document.body.classList.remove("dark-mode");
            localStorage.setItem("darkMode", "disabled");
        }
    });
});

function toggleMusic() {
    const music = document.getElementById("bg-music");
    const musicBtn = document.getElementById("music-btn");

    if (music.paused) {
        music.play();
        musicBtn.textContent = "Music: ON";
        localStorage.setItem("music", "on");
    } else {
        music.pause();
        musicBtn.textContent = "Music: OFF";
        localStorage.setItem("music", "off");
    }
}

// Open & close settings modal
function openSettings() {
    document.getElementById("settings-modal").style.display = "block";
}

function closeSettings() {
    document.getElementById("settings-modal").style.display = "none";
}
document.addEventListener("DOMContentLoaded", function () {
    const music = document.getElementById("bg-music");
    const musicBtn = document.getElementById("music-btn");
    const darkModeToggle = document.getElementById("dark-mode-toggle");

    // Load Dark Mode Preference
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        if (darkModeToggle) darkModeToggle.checked = true;
    }

    // Load Music Preference
    if (localStorage.getItem("music") === "on") {
        music.play();
        if (musicBtn) musicBtn.textContent = "Music: ON";
    }

    // Dark Mode Toggle
    if (darkModeToggle) {
        darkModeToggle.addEventListener("change", function () {
            if (this.checked) {
                document.body.classList.add("dark-mode");
                localStorage.setItem("darkMode", "enabled");
            } else {
                document.body.classList.remove("dark-mode");
                localStorage.setItem("darkMode", "disabled");
            }
        });
    }
});
// Function to play the click sound
    function playClickSound() {
        const sound = document.getElementById("click-sound");
        sound.currentTime = 0; // Reset sound to start
        sound.play();
    }

    // Attach the click event to all buttons
    document.addEventListener("DOMContentLoaded", function () {
        const buttons = document.querySelectorAll("button");
        buttons.forEach(button => {
            button.addEventListener("click", playClickSound);
        });
    });



