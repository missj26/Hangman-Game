function displayScoreAndStars() {
  const scoreFeedback = document.getElementById("score-feedback");
  const starRating = document.getElementById("star-rating");

  // Retrieve the score from localStorage (default to 0 if not found)
  const score = parseInt(localStorage.getItem("score")) || 0;
  scoreFeedback.textContent = score;

  // Calculate filled stars: using score/20, but cap at 3
  let filledStars = Math.min(Math.floor(score / 20), 3);

  // Build star rating string: filled stars vs unfilled stars (always total of 3)
  let stars = "";
  for (let i = 0; i < filledStars; i++) {
    stars += "⭐";
  }
  for (let i = filledStars; i < 3; i++) {
    stars += "☆";
  }
  starRating.textContent = stars;
}
function endGame() {
    // Send score to the database before deleting
    const playerName = sessionStorage.getItem("player_name");
    const score = parseInt(sessionStorage.getItem("score")) || 0;

    fetch('/save_score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ player_name: playerName, score: score })
    })
    .then(response => response.json())
    .then(() => {
        // After saving, clear session data
        sessionStorage.removeItem("player_name");
        sessionStorage.removeItem("score");
    })
    .catch(error => console.error('Error saving score:', error));
}

// Run when the player exits
window.addEventListener("beforeunload", () => {
    sessionStorage.removeItem("player_name");
    sessionStorage.removeItem("score");
});