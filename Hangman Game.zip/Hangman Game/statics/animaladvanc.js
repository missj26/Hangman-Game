// words.js - Contains categorized words and questions

const wordsData = [
           { "word": "platypus", question: "Which egg-laying mammal is known for its duck-like bill?" },
  { "word": "cheetah", question: "Which animal is the fastest land animal?" },
  { "word": "hippopotamus", question: "Which large animal spends most of its time in water and has large tusks?" },
  { "word": "polar bear", question: "Which bear species lives in the Arctic?" },
  { "word": "penguin", question: "Which flightless bird is known for living in cold climates?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over12";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   