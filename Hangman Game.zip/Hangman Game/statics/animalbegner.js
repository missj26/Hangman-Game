// words.js - Contains categorized words and questions

const wordsData = [
          { "word": "cat", question: "Which animal is often kept as a pet and meows?" },
  { "word": "dog", question: "Which animal is known as man's best friend?" },
  { "word": "cow", question: "Which animal is commonly found on farms and gives milk?" },
  { "word": "horse", question: "Which large animal is often used for riding?" },
  { "word": "fish", question: "Which aquatic animal has scales and swims in water?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over10";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   