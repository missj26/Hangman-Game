// words.js - Contains categorized words and questions

const wordsData = [
         { "word": "lemon", question: "Which yellow fruit is sour and often used in drinks and desserts?" },
  { "word": "lime", question: "Which green fruit is sour and often used in cocktails?" },
  { "word": "coconut", question: "Which tropical fruit has a hard brown shell and white flesh?" },
  { "word": "nectarine", question: "Which smooth-skinned fruit is similar to a peach?" },
  { "word": "persimmon", question: "Which fruit is sweet and orange, often eaten when fully ripe?" },
  { "word": "applesauce", question: "Which fruit-based product is made from pureed apples?" },
  { "word": "tangerine", question: "Which small citrus fruit is easy to peel and sweet in flavor?" },
  { "word": "blackberry", question: "Which dark purple fruit is used in jam and pies?" },
  { "word": "raspberry", question: "Which small, red fruit is often used in smoothies and desserts?" },
  { "word": "clementine", question: "Which small, seedless citrus fruit is often sold in easy-to-peel segments?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  

    saveAndRedirect();
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 

   saveAndRedirect(); 
setTimeout(() => {
window.location.href = "/game-over3";
}, 2000);
}

}
   