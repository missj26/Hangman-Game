// words.js - Contains categorized words and questions

const wordsData = [
             { "word": "computer", question: "Which device is used for working with information and browsing the internet?" },
  { "word": "glove", question: "Which item do you wear on your hand for warmth or protection?" },
  { "word": "umbrella", question: "Which object is used to protect you from rain?" },
  { "word": "camera", question: "Which device is used to take photographs?" },
  { "word": "key", question: "Which item is used to unlock doors?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over8";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   