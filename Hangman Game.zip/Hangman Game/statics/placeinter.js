// words.js - Contains categorized words and questions

const wordsData = [
           { "word": "museum", question: "Where can you see historical artifacts and art?" },
  { "word": "zoo", question: "Which place is home to a variety of animals for public viewing?" },
  { "word": "mountain", question: "Which large landform is high and typically covered in snow?" },
  { "word": "forest", question: "Which dense area is full of trees and wildlife?" },
  { "word": "stadium", question: "Where do large crowds gather to watch sports events?" }
    ];
   // Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
                setTimeout(() => {
window.location.href = "/game-over5";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}