// words.js - Contains categorized words and questions

const wordsData = [
           { "word": "beach", question: "Which place is known for its sand, waves, and sun?" },
  { "word": "park", question: "Which public area is filled with trees, grass, and playgrounds?" },
  { "word": "school", question: "Where do children go to learn?" },
  { "word": "restaurant", question: "Where can you go to eat food at a table?" },
  { "word": "library", question: "Where do people go to borrow books?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over4";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   