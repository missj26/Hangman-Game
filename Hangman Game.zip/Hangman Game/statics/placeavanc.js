// words.js - Contains categorized words and questions

const wordsData = [
            { "word": "antarctica", question: "Which cold continent is mostly covered in ice?" },
  { "word": "eiffeltower", question: "Which famous landmark is located in Paris, France?" },
  { "word": "greatbarrierreef", question: "Which natural wonder is a large coral reef off the coast of Australia?" },
  { "word": "sahara", question: "Which desert is the largest hot desert in the world?" },
  { "word": "machupicchu", question: "Which ancient Incan city is located in Peru?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over6";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   