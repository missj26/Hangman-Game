// words.js - Contains categorized words and questions

const wordsData = [
         { "word": "pineapple", question: "Which tropical fruit has a spiky exterior and sweet interior?" },
  { "word": "cherry", question: "Which small, red fruit is often used in pies and cocktails?" },
  { "word": "watermelon", question: "Which large, green fruit is sweet and juicy inside?" },
  { "word": "papaya", question: "Which tropical fruit is orange and has black seeds?" },
  { "word": "plum", question: "Which small, round fruit comes in purple, red, and yellow varieties?" },
  { "word": "apricot", question: "Which fruit is orange and often dried to make a snack?" },
  { "word": "cantaloupe", question: "Which orange-fleshed melon is sweet and often served chilled?" },
  { "word": "fig", question: "Which fruit is small, purple or green, and often eaten dried?" },
  { "word": "pomegranate", question: "Which fruit is known for its numerous seeds and juicy interior?" },
  { "word": "dragonfruit", question: "Which fruit has bright pink skin and white flesh speckled with tiny seeds?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
                setTimeout(() => {
window.location.href = "/game-over2";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   