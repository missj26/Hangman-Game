// words.js - Contains categorized words and questions

const wordsData = [
           { "word": "elephant", question: "Which large animal has a trunk and large ears?" },
  { "word": "giraffe", question: "Which animal is the tallest land animal?" },
  { "word": "tiger", question: "Which animal is known for its stripes and is a big cat?" },
  { "word": "kangaroo", question: "Which animal is native to Australia and hops on its hind legs?" },
  { "word": "lion", question: "Which animal is known as the king of the jungle?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over11";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   