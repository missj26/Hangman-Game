// words.js - Contains categorized words and questions

const wordsData = [
         { "word": "apple", question: "Which fruit is red and keeps the doctor away?" },
  { "word": "banana", question: "Which fruit is yellow and monkeys love to eat?" },
  { "word": "grape", question: "Which small fruit grows in bunches and is used to make wine?" },
  { "word": "orange", question: "Which citrus fruit is named after its color?" },
  { "word": "mango", question: "Which tropical fruit is known as the 'king of fruits'?" },
  { "word": "pear", question: "Which fruit is shaped like an oval and comes in green or yellow?" },
  { "word": "peach", question: "Which fruit has a fuzzy skin and is often used in pies?" },
  { "word": "kiwi", question: "Which small, brown, fuzzy fruit has green flesh and black seeds?" },
  { "word": "strawberry", question: "Which red fruit has tiny seeds on its surface?" },
  { "word": "blueberry", question: "Which small, blue fruit is often used in muffins?" }
    ];
// Check win or lose status
function checkGameStatus() {
const message = document.getElementById("message");
if (!message) return;

if (!document.getElementById("word-display").textContent.includes("_")) {  
    message.textContent = "You Survived!";  
    message.style.color = "green";  
    gameOver = true;  
    saveAndRedirect();  
} else if (wrongGuesses >= 6) {  
    message.textContent = "Game Over! The word was: " + chosenWord;  
    message.style.color = "red";  
    gameOver = true; 
   saveAndRedirect();  
}
let restart = document.getElementById("restart");
            if (wrongGuesses >= 6) {
               setTimeout(() => {
window.location.href = "/game-over1";
}, 2000); 
                
            } 
else if(!document.getElementById("word-display").textContent.includes("_")) { 
setTimeout(() => {
window.location.href = "/game-over";
}, 2000); 
}
}
   