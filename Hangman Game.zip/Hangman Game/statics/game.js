// Wait for the DOM to fully load before initializing the game
document.addEventListener("DOMContentLoaded", function () {
initializeGame();
});

let chosenData, chosenWord, relatedQuestion;
let guessedLetters = [];
let wrongGuesses = 0;
let gameOver = false;
let score = 0; // Score variable

// Initialize game
function initializeGame() {
console.log("Initializing game...");
resetGameVariables();
updateQuestionDisplay();
updateWordDisplay();
createKeyboard();
}

// Reset game variables for a new round
function resetGameVariables() {
if (wordsData.length === 0) {
console.error("No words available! Keyboard will still be created.");
chosenWord = ""; // Prevent errors
relatedQuestion = "No words available!";
gameOver = true;
createKeyboard(); // Still generate keyboard to prevent UI issues
return;
}

chosenData = wordsData[Math.floor(Math.random() * wordsData.length)];  
chosenWord = chosenData.word;  
relatedQuestion = chosenData.question;  
guessedLetters = [];  
wrongGuesses = 0;  
gameOver = false;  
score = 0;  

createKeyboard();

}

// Update question display
function updateQuestionDisplay() {
const questionElement = document.getElementById("question-display");
if (questionElement) {
questionElement.textContent = "Q: " + relatedQuestion;
console.log("Question displayed:", relatedQuestion);
}
}

// Update word display
function updateWordDisplay() {
const wordDisplay = document.getElementById("word-display");
if (wordDisplay) {
wordDisplay.textContent = chosenWord.split("")
.map(letter => (guessedLetters.includes(letter) ? letter : "_"))
.join(" ");
}
updateStars();
checkGameStatus();
}

// Create on-screen keyboard
function createKeyboard() {
const keyboardDiv = document.getElementById("keyboard");
if (!keyboardDiv) {
console.error("Keyboard div not found!");
return;
}

keyboardDiv.innerHTML = ""; // Clear existing keyboard  

"abcdefghijklmnopqrstuvwxyz".split("").forEach(letter => {  
    const button = document.createElement("button");  
    button.textContent = letter;  
    button.classList.add("keyboard-button");  
    button.onclick = () => handleGuess(letter);  
    keyboardDiv.appendChild(button);  
});  

console.log("Keyboard created successfully.");

}

// Handle guessed letter
function handleGuess(letter) {
if (gameOver || guessedLetters.includes(letter) || wrongGuesses >= 6) return;

guessedLetters.push(letter);  

if (chosenWord.includes(letter)) {  
    score += 10; // Increase score for correct guess  
} else {  
    wrongGuesses++;  
    drawHangman();  
    score -= 5; // Decrease score for wrong guess 

}  
updateWordDisplay();

}

// Draw Hangman based on wrong guesses
function drawHangman() {
const canvas = document.getElementById("hangman-canvas");
if (!canvas) return;

const ctx = canvas.getContext("2d");  
ctx.lineWidth = 3;  
ctx.strokeStyle = "white";  

// Clear previous drawings  
ctx.clearRect(0, 0, canvas.width, canvas.height);  

// Draw the gallows  
ctx.beginPath();  
ctx.moveTo(30, 180); ctx.lineTo(170, 180); // Base  
ctx.moveTo(100, 180); ctx.lineTo(100, 20); // Pole  
ctx.moveTo(100, 20); ctx.lineTo(140, 20);  // Top beam  
ctx.moveTo(140, 20); ctx.lineTo(140, 40);  // Rope  

// Draw Hangman progressively  
if (wrongGuesses >= 1) ctx.arc(140, 55, 15, 0, Math.PI * 2); // Head  
if (wrongGuesses >= 2) ctx.moveTo(140, 70), ctx.lineTo(140, 120); // Body  
if (wrongGuesses >= 3) ctx.moveTo(140, 80), ctx.lineTo(120, 110); // Left Arm  
if (wrongGuesses >= 4) ctx.moveTo(140, 80), ctx.lineTo(160, 110); // Right Arm  
if (wrongGuesses >= 5) ctx.moveTo(140, 120), ctx.lineTo(120, 160); // Left Leg  
if (wrongGuesses >= 6) ctx.moveTo(140, 120), ctx.lineTo(160, 160); // Right Leg (Complete Hang)  

ctx.stroke();

}

// Update star display based on score
function updateStars() {
    const starContainer = document.getElementById("stars");
    if (!starContainer) return;

    // If there are no wrong guesses, show 3 filled stars.
    // Otherwise, show 3 unfilled stars.
    if (wrongGuesses === 0) {
        starContainer.innerHTML = "⭐⭐⭐";
    } else {
        starContainer.innerHTML = "☆☆☆";
    }
}


// Restart game
function restartGame() {
resetGameVariables();
updateQuestionDisplay();
updateWordDisplay();

const message = document.getElementById("message");  
if (message) message.textContent = "";  

const canvas = document.getElementById("hangman-canvas");  
if (canvas) {  
    const ctx = canvas.getContext("2d");  
    ctx.clearRect(0, 0, canvas.width, canvas.height);  
}  

createKeyboard();

}

// Handle real keyboard input
document.addEventListener("keydown", (event) => {
let letter = event.key.toLowerCase();
if (/^[a-z]$/.test(letter)) {
handleGuess(letter);
}
});

// Save score and redirect to Game Over page
function saveAndRedirect() {
localStorage.setItem("score", score);
setTimeout(() => {
window.location.href = "/game-over";
}, 2000);
}